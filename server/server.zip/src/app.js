const express = require('express');
const cors = require('cors');
require('dotenv').config();

const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const testRoutes = require('./routes/testRoutes');
const attendanceRoutes = require('./routes/attendanceRoutes');
const markRoutes = require('./routes/markRoutes');
const grievanceRoutes = require('./routes/grievanceRoutes');
const noticeRoutes = require('./routes/noticeRoutes');


const app = express();

connectDB();

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/test', testRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/marks', markRoutes);
app.use('/api/grievances', grievanceRoutes);
app.use('/api/notices', noticeRoutes);

app.get('/', (req, res) => {
  res.send('Backend is running');
});


module.exports = app;
