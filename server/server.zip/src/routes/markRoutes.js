const express = require('express');
const router = express.Router();
const { addMark, getMyMarks } = require('../controllers/markController');
const { protect, authorize } = require('../middlewares/authMiddleware');

// Faculty adds marks
router.post(
  '/',
  protect,
  authorize('faculty'),
  addMark
);

// Student views marks
router.get(
  '/my',
  protect,
  authorize('student'),
  getMyMarks
);

module.exports = router;
