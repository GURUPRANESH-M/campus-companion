const Mark = require('../models/Mark');

// Faculty uploads marks
exports.addMark = async (req, res) => {
  try {
    const { studentId, subject, examType, score, maxScore } = req.body;

    const mark = await Mark.create({
      student: studentId,
      subject,
      examType,
      score,
      maxScore,
      enteredBy: req.user._id
    });

    res.status(201).json(mark);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Student views marks
exports.getMyMarks = async (req, res) => {
  try {
    const marks = await Mark.find({ student: req.user._id });
    res.json(marks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
