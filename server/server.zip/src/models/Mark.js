const mongoose = require('mongoose');

const markSchema = new mongoose.Schema(
  {
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    subject: {
      type: String,
      required: true
    },
    examType: {
      type: String,
      enum: ['CAT1', 'CAT2', 'MODEL'],
      required: true
    },
    score: {
      type: Number,
      required: true
    },
    maxScore: {
      type: Number,
      default: 100
    },
    enteredBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    }
  },
  { timestamps: true }
);

// Prevent duplicate marks entry
markSchema.index(
  { student: 1, subject: 1, examType: 1 },
  { unique: true }
);

module.exports = mongoose.model('Mark', markSchema);
